devtools::install_github("role-model/roleShiny",force=TRUE)
roleShiny::run_app()
