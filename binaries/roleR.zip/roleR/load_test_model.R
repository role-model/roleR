# load test run role experiment
test_exp <- readRDS("data/example_out_in/test.roleexperiment")

writeRoleExperiment(test_ex)



