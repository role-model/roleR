remotes::install_github("role-model/roleR")

install.packages('https://github.com/eco-evo-thr-2022/06-simulating-untb/raw/main/roleR_0.1.0.tgz',
                 type='binary',repos=NULL)#,lib = "C:/Users/hiest/AppData/Local/R/win-library/4.2")
sessionInfo()

setInternet2(TRUE)
install.packages('D:/roleR.tgz',type='binary',repos=NULL)#,lib = "C:/Users/hiest/AppData/Local/R/win-library/4.2")
install.packages("D:/roleR2.zip",repos=NULL,type="win.binary")
sessionInfo()
.libPaths()

install.packages('D:/roleR.tgz', repos = NULL, type = "win.binary")
